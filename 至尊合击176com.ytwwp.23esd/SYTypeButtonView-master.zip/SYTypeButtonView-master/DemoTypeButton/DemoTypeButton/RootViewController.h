//
//  RootViewController.h
//  DemoTypeButton
//
//  Created by zhangshaoyu on 2017/12/29.
//  Copyright © 2017年 zhangshaoyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
