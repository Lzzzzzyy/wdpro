//
//  SYButton.h
//  HKCloud
//
//  Created by zhangshaoyu on 15/11/16.
//  Copyright © 2015年 zhangshaoyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYButton : UIButton

@end
