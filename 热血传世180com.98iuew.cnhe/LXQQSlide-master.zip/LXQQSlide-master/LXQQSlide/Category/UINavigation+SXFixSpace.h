//
//  UINavigation+SXFixSpace.h
//  UINavigation-SXFixSpace
//
//  Created by charles on 2017/9/8.
//  Copyright © 2017年 None. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef sx_defaultFixSpace
#define sx_defaultFixSpace 8
#endif

@interface UINavigationController (SXFixSpace)
@end

@interface UINavigationBar (SXFixSpace)
@end

@interface UINavigationItem (SXFixSpace)
@end

