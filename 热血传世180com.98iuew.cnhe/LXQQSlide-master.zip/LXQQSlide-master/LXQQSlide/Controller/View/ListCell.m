//
//  ListCell.m
//  LXQQSlide
//
//  Created by chenergou on 2017/12/26.
//  Copyright © 2017年 漫漫. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
